package br.com.controle;
/**
 *
 * @author William Vieira
 */
public class Servico {
   private int codigo;
   private String nome;
   private double valorservico;
   private int quantidade;
   private double total;
   double maiorvalor=0;
   double totalrecebido=0;
   int valor;
   
   //=============Metodos GET e SET=================

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getValorservico() {
        return valorservico;
    }

    public void setValorservico(double valorservico) {
        this.valorservico = valorservico;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getMaiorvalor() {
        return maiorvalor;
    }

    public void setMaiorvalor(double maiorvalor) {
        this.maiorvalor = maiorvalor;
    }

    public double getTotalrecebido() {
        return totalrecebido;
    }

    public void setTotalrecebido(double totalrecebido) {
        this.totalrecebido = totalrecebido;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
    
   

    
   
    //=============Metodos para tela=================
    public double valorAtendimento(){
        this.total = this.valorservico*this.quantidade;
        return this.total;
    }
    
    public double totalRecebido(){
        totalrecebido=totalrecebido+this.total;
        return totalrecebido;
    }
    
    public double maiorValor(){
        if(this.total>maiorvalor){
            maiorvalor=total;
        }
        return maiorvalor;
    }
}
